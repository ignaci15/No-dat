from django.contrib import admin
from proa.models import Alumno,Curso,Profesor,Materia,Calificaciones
admin.site.register(Alumno)
admin.site.register(Curso)
admin.site.register(Profesor)
admin.site.register(Materia)
admin.site.register(Calificaciones)